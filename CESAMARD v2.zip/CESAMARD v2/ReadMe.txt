Research work: Please see the picture attached. Towards Multimodal Complaint Severity Detection from Social Media

Dataset: Complaint,Severity, Emotion, and Sentiment Annotated Multi-modal Complaint Dataset (CESAMARD v2)

Description: Each record in the CESAMARD v2 dataset consists of the page URL, domain, image URL,image name, review title, review text, complaint, sentiment, emotion and corresponding annotated severity labels. 
Another file consists of the images corresponding to the dataset records.
